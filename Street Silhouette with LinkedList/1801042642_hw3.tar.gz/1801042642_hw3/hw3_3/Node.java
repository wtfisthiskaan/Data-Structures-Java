public class Node
{
    public Building b;
    public Node next;
    public Node(Building b)
    {
        this.b = b;
        next = null;
    }
    
}